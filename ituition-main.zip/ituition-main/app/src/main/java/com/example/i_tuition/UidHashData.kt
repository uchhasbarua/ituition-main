package com.example.i_tuition

data class UidHashData(
    val uid : String?,
    val hash : String?
) {

}
