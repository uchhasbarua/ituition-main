package com.example.i_tuition

data class StudentClass (
    var FirstName : String?,
    var LastName: String?,
    var Age: String?,
    var Address: String?,
    var Email : String?
        ) {

}
