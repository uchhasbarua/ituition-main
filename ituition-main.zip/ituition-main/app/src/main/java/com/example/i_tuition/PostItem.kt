package com.example.i_tuition

data class PostItem(
    var FirstName : String?,
    var LastName : String?,
    var Class : String?,
    var Subjects : String?,
    var WeekDays : String?,
    var Fee : String?,
    var Description : String?
) {}
