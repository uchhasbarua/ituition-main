package com.example.i_tuition

data class TeacherClass (
    var FirstName : String?,
    var LastName: String?,
    var Age: String?,
    var Institution: String?,
    var Undergraduate: Boolean?,
    var Email : String?
        ) {

}
