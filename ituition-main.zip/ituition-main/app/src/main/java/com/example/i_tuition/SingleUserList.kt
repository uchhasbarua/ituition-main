package com.example.i_tuition

data class SingleUserList(
    var FullName : String?
) {

}
