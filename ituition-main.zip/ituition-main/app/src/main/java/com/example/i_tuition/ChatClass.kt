package com.example.i_tuition

data class ChatClass(
    val senderId : String?,
    val receiverId : String?,
    val message : String?
) {

}
